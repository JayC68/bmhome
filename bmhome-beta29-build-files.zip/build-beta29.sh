#!/usr/bin/env bash
set -euo pipefail
cd /Users/Jon/bmhome
echo "== BMHome v0.1.0-beta.29 public beta polish =="
npm login
npm whoami
rm -f homebridge-bmhome-*.tgz
node scripts/set-beta29-package.js
python3 scripts/remove-preconditioning.py
python3 scripts/write-beta29-docs.py
npm install
npm run build
node scripts/validate-beta29.js
npm pack --dry-run
git add package.json package-lock.json README.md CHANGELOG.md .homebridge/release-notes.md src/vehicleAccessory.ts scripts/
git add -u package.json package-lock.json README.md CHANGELOG.md .homebridge/release-notes.md src/vehicleAccessory.ts scripts/
if git diff --cached --quiet; then echo "No staged release changes; stopping."; exit 1; fi
git commit -m "Polish public beta HomeKit surface and documentation"
git push -u origin "$(git branch --show-current)"
npm publish
npm view homebridge-bmhome@0.1.0-beta.29 version description
npm view homebridge-bmhome@0.1.0-beta.29 engines --json
echo "== BMHome beta.29 complete =="
