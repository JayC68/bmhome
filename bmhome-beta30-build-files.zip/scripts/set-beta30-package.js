const fs = require('fs');

const p = 'package.json';
const pkg = JSON.parse(fs.readFileSync(p, 'utf8'));

pkg.version = '0.1.0-beta.30';
pkg.description = 'BMHome - BMW CarData telemetry for Apple Home via Homebridge';
pkg.displayName = 'BM Home';
pkg.repository = { type: 'git', url: 'git+https://github.com/JayC68/bmhome.git' };
pkg.bugs = { url: 'https://github.com/JayC68/bmhome/issues' };
pkg.homepage = 'https://bmhome.kernowekconsulting.co.uk';

pkg.keywords = [
  'homebridge-plugin',
  'homebridge',
  'bmhome',
  'bmw',
  'mini',
  'apple-home',
  'homekit',
  'cardata',
  'telemetry',
  'ev',
  'mqtt'
];

pkg.engines = {
  node: '^22.0.0 || ^24.0.0',
  homebridge: '^1.8.0 || ^2.0.0'
};

fs.writeFileSync(p, JSON.stringify(pkg, null, 2) + '\n');
console.log('Updated package.json to 0.1.0-beta.30');
