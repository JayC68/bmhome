from pathlib import Path
import re

p = Path("src/vehicleAccessory.ts")
s = p.read_text()
original = s

s = re.sub(r"\n\s*private\s+lockService!:\s*Service;\n", "\n", s)

s = re.sub(
    r"\n\s*this\.lockService\s*=\s*\n"
    r"\s*accessory\.(?:getService|getServiceById)\([\s\S]*?\)\s*\?\?\s*\n"
    r"\s*accessory\.addService\(api\.hap\.Service\.LockMechanism,[\s\S]*?'lock'\);\n",
    "\n",
    s,
)

s = re.sub(r"\n\s*this\.setServiceName\(this\.lockService,\s*'BMW Lock'\);\n", "\n", s)

s = re.sub(
    r"\n\s*this\.lockService\n"
    r"\s*\.getCharacteristic\(Characteristic\.LockTargetState\)\n"
    r"\s*\.onSet\(async \(value\) => \{\n"
    r"[\s\S]*?"
    r"\n\s*\}\);\n",
    "\n",
    s,
)

s = re.sub(
    r"\n\s*if \(data\.lockStatus && data\.lockStatus !== 'unknown'\) \{\n"
    r"[\s\S]*?"
    r"\n\s*\}\n\s*\n\s*if \(data\.soc !== undefined\) \{",
    "\n    if (data.soc !== undefined) {",
    s,
)

s = re.sub(
    r"\n\s*private\s+updateLock[\s\S]*?\n\s*\}\n(?=\n\s*private|\n\})",
    "\n",
    s,
)

s = re.sub(r"\n\s*this\.updateLockState\([^)]*\);\n", "\n", s)

p.write_text(s)

if s == original:
    print("No lock tile patterns changed; validating current source may already be lock-free.")
else:
    print("Removed active LockMechanism tile from src/vehicleAccessory.ts")
