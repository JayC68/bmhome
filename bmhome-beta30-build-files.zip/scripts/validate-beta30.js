const fs = require('fs');

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const accessory = fs.readFileSync('dist/vehicleAccessory.js', 'utf8');
const source = fs.readFileSync('src/vehicleAccessory.ts', 'utf8');
const readme = fs.readFileSync('README.md', 'utf8');
const changelog = fs.readFileSync('CHANGELOG.md', 'utf8');
const releaseNotes = fs.readFileSync('.homebridge/release-notes.md', 'utf8');

if (pkg.version !== '0.1.0-beta.30') throw new Error('version not beta.30');
if (!pkg.engines?.homebridge?.includes('2.0.0')) throw new Error('Homebridge 2.x engine missing');
if (!pkg.engines?.node?.includes('24.0.0')) throw new Error('Node 24 engine missing');

for (const term of ['BMW Battery', 'BMW Windows', 'BMW Boot', 'BMW Tyres']) {
  if (!accessory.includes(term)) throw new Error(term + ' tile missing from dist');
}

for (const forbidden of [
  'BMW Lock',
  'LockMechanism',
  'LockTargetState',
  'LockCurrentState',
  'lockService',
  'BMW Preconditioning',
  'HeaterCooler'
]) {
  if (accessory.includes(forbidden)) throw new Error(forbidden + ' remains in dist/vehicleAccessory.js');
  if (source.includes(forbidden)) throw new Error(forbidden + ' remains in src/vehicleAccessory.ts');
}

for (const term of [
  'BMW CarData Stream',
  'telemetry-only',
  'Why BMHome Does Not Lock or Unlock the Car',
  'Use the newest code shown',
  'BMHome does not attempt to bypass BMW platform restrictions'
]) {
  if (!readme.includes(term)) throw new Error(term + ' missing from README');
}

if (!changelog.includes('0.1.0-beta.30')) throw new Error('CHANGELOG beta.30 missing');
if (!releaseNotes.includes('BMHome 0.1.0-beta.30')) throw new Error('release notes beta.30 missing');

console.log('Validation OK');
